# SmartSpace_29-07-23
Learn how to build a stunning and responsive Real Estate Website Landing Page from scratch using HTML and CSS
